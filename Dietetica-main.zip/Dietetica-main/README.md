# Dietetica

Este proyecto consiste en administrar las ventas diarias de un negocio: ingresandolas, en la cual podes borrar solamente las del dia actual y con esos datos sacar conclusiones como: venta total del dia, mes, año, también, dia que más y menos se vendió, promedio por dia entre otras.

En las carpetas esta el codigo y una llamada 'imagenes del proyecto' en la que van a ver como esta hecho.

Para realizar este programa use la modalidad de MVC en PHP.
Lenguajes utilizados: HTML - PHP - Bootstrap 4 ,CSS , base de datos MySQL
