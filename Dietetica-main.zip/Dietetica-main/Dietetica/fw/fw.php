<?php 

require 'Database.php';
require 'Model.php';
require 'View.php';

