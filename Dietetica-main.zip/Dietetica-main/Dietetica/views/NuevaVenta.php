<!--  ../views/NuevaVenta.php  -->

<?php 

	class NuevaVenta extends View {
			
		public $ventas ;
		public $total ;

	}
