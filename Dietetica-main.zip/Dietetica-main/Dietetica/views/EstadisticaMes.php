<?php 

/* ../views/EstadisticaMes.php */

	class EstadisticaMes extends View {

		public $totalMes ;
		public $promedioDia ;
		public $diaMax ;
		public $diaMin ;
		public $nombreMes ;
		public $lista ;

	}

?>