<!--  ../views/ListaVentasDelMes.php  -->

<?php 


	class ListaVentasDelMes extends View {

		public $lista ;
		public $mes ;
		public $total ;
		
	}