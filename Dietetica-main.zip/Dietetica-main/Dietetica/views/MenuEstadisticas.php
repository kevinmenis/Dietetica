<!--  ../views/MenuEstadistica.php  -->

<?php 


	class MenuEstadisticas extends View {
		

	}