<!--  ../views/ListaVentasDelDia.php  -->

<?php 

	class ListaVentasDelDia extends View {

		public $lista ;
		public $total ;
		public $listaHoy ;
		public $totalHoy ;
			
	}
