<?php 

	require '../html/Partials/Header.php' ;

?>			

		<header>
			<nav class="menu">
				<ul>					
					<li> <a href="../controllers/menu-principal.php"><span class="icon-home"></span> Inicio</a> </li>

					<li> <a href="../controllers/estadistica-mes.php">Estadística del mes</a> </li>	

					<li> <a href="../controllers/estadistica-año.php">Estadística del año</a> </li>
				</ul>				
			</nav>	
		</header>

<?php 

	require '../html/Partials/Header.php' ;

?>	